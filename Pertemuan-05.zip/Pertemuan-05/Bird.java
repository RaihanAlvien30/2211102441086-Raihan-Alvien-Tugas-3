import greenfoot.*;
import java.util.Random;

public class Bird extends Actor {
    private GreenfootImage image1;
    private GreenfootImage image2;    
    private int frame = 1;
    private int animationDelay = 10;
    private int speed = 5; // Kecepatan gerakan Burung

    public Bird()
    {
        image1 = new GreenfootImage("1.png");
        image2 = new GreenfootImage("2.png");

        image1.scale(image1.getWidth() / 9, image1.getHeight() / 9);
        image2.scale(image2.getWidth() / 9, image2.getHeight() / 9);

        setImage(image1);
    }
    
    public void act() 
    {
        animate();
        moveBird();
    }

    private void animate()
    {
        if (frame == animationDelay)
        {
            switchImage();
            frame = 1;
        }
        else
        {
            frame++;
        }
    }

    private void switchImage()
    {
        if (getImage() == image1)
        {
            setImage(image2);
        }
        else if (getImage() == image2)
        {
            setImage(image1);
        }
        else
        {
            setImage(image1);
        }
    }
    
    private void moveBird()
    {
        int x = getX();
        int y = getY();
        
        if (Greenfoot.mouseMoved(null))
        {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        int mouseX = mouse.getX();
        int mouseY = mouse.getY();
        
        int deltaX = mouseX - x;
        int deltaY = mouseY - y;
        
        double angle = Math.toDegrees(Math.atan2(deltaY, deltaX));
        
        x += (int) (speed * Math.cos(Math.toRadians(angle)));
        y += (int) (speed * Math.sin(Math.toRadians(angle)));
        }
        
        setLocation(x,y);
    }
}